package com.capglab;


import java.util.Set;
import java.util.TreeSet;
import java.lang.Integer;

public class Lab1 {
		
	public void getSorted(int a[]) {
		String SArray[]=new String[a.length];
		
		for (int i = 0; i < a.length; i++)
		{
			
			SArray[i]=String.valueOf(a[i]);
			
			StringBuilder stringReverse=new StringBuilder(SArray[i]);		  
		   SArray[i]=stringReverse.reverse().toString();
			a[i]=Integer.parseInt(SArray[i]);
		}
		

		Set<Integer> st=new TreeSet<Integer>();
		for (int i = 0; i < a.length; i++)
		{
			st.add(a[i]);
			
		}
		System.out.println(st);                                                                                                                                                                                                                                                                                                                                                                                                

		
	}

	public static void main(String[] args) {
		
		Lab1 a=new Lab1();
		int ar[]= {10,65,78};
 
		a.getSorted(ar);
		
}
}