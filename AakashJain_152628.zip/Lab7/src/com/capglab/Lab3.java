package com.capglab;

import java.util.ArrayList;
import java.util.List;

public class Lab3 {
	
	public static List<String> removeElements(List<String> list1,List<String> list2)
	{		
		list1.removeAll(list2);
	    return list1;
	}
	

	public static void main(String[] args) {
		List<String> list1=new ArrayList<String>();
		List<String> list2=new ArrayList<String>();
		
		list1.add("A");
		list1.add("B");
		list1.add("C");
		list1.add("D");
		list2.add("A");
		list2.add("C");
		
		List<String> list3=new ArrayList<String>();
		list3=removeElements(list1,list2);
		System.out.println(list3);
		
	}

}
