package com.capglab;

import java.util.HashMap;

import java.util.Map;
import java.util.Scanner;

public class Lab4 {
	
	public static Map<Integer,Integer> getSquares(int a[])
	{
	Map<Integer,Integer> nug=new HashMap<Integer,Integer>();
	for (int i = 0; i < a.length; i++)
	{
	nug.put(a[i], a[i]*a[i]);
	}
	
	System.out.println();
	return nug;
	}

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		
		for (int i = 0; i < 5; i++) 
		{
			a[i]=sc.nextInt();
		}
		sc.close();
		Map<Integer,Integer> pug=new HashMap<Integer,Integer>();
		pug=getSquares(a);
		System.out.println(pug);
	}

}
