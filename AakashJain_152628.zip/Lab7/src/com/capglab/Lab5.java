package com.capglab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Lab5 {
	public static void main(String[] args)
	{
		List<String> list1=new ArrayList<String>();
		list1.add("A k hash");
		list1.add("Aak");
		list1.add("Aakasssss");
		list1.add("Aaaa");
		Collections.sort(list1);
		
		for (String st : list1) {
			System.out.println(st);
		}
		
	}

}
