package com.capglab;

public class SavingsAccount4_2 extends Account4_2{
	
	final int minbal=500;
	@Override
	public boolean withdraw(double w)
	{
		Account4_1 a=new Account4_1();
		double balance=a.getBalance();
		 balance=balance-w;
		  if(balance<minbal)
		  {
			  System.out.println("no balance");
			  return true;
		  }
		  return false;
		}
		
	}
	
	



