package com.capglab;

public  class Account4_1 extends Person4_1 {
private long accountNum;
private double balance;
private Person4_1 accHolder;

public void deposit(double d) 
	{
	   balance=balance+d;
	   System.out.println("account balance is"+ balance);
	}
public double withdraw(double w) 
	{
	  balance=balance-w;
	  if(balance<500)
	  {
		  System.out.println("no balance");
		  return w;
	  }
	  return balance+w;
	}
public double getBalance()
	{
	 return balance;
	}

public long getAccountNum() {
	return accountNum;
}
public void getBalance(double balance) {
	this.balance = balance;
}	
public void setAccHolder(Person4_1 accHolder) {
	this.accHolder= accHolder;
}
public String getAccHolder() {
	return accHolder.getName();
}
public void setAccountNum(long accountNum) {
	this.accountNum = accountNum;
}
public void setBalance(double balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "Account4_1 [accountNum=" + accountNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
}


}
