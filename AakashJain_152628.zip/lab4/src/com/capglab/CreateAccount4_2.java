package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CreateAccount4_2 extends Person4_1 {


		public static void main(String[] args) {
			
			long accNum=(long)((Math.random()*((100000-10000)+1))+110000);
	
			
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			String name = null;
			float age=0.0f;
			int dorw=0;
			try {
				System.out.println("enter customer name");
				name = br.readLine();
				System.out.println("enter customer age");
				age = Float.parseFloat(br.readLine());
				System.out.println("Select from following");
				System.out.println("1:deposit");
				System.out.println("2:withdraw");
				dorw=Integer.parseInt(br.readLine());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			Account4_2  acc= new Account4_2();
			
			acc.setName(name);
			acc.setAge(age);

			acc.setAccountNum(accNum);
			System.out.println(acc.toString());
			switch (dorw) {
			case 1:
				System.out.println("enter the amount you want to deposit");
				Integer amountd = 0;
				try {
					amountd = Integer.parseInt(br.readLine());
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				acc.deposit(amountd);
				break;

			case 2:
				System.out.println("enter the amount you want to withdraw");
				Integer amountw = 0;
				try {
					amountw = Integer.parseInt(br.readLine());
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				acc.withdraw(amountw);
				break;

			default:
				break;
				
				
			
			}
			
		
			
			
		}
	}

