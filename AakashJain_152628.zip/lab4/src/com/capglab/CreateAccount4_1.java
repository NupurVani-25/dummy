package com.capglab;

/*import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;*/

public class CreateAccount4_1 {

	public static void main(String[] args) {
		
		long accNum=(long)((Math.random()*((100000-10000)+1))+110000);
Account4_1  acc1= new Account4_1();
		
		acc1.setName("smith");
		acc1.setAccountNum(accNum);
		acc1.setBalance(2000);
		acc1.deposit(2000);
		System.out.println(acc1.toString());
		
Account4_1  acc2= new Account4_1();
		
		acc2.setName("smith");
		acc2.setAccountNum(accNum+1);
		acc2.setBalance(3000);
		acc2.withdraw(1000);
		System.out.println(acc2.toString());
		
/*BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String name = null;
		float age=0.0f;
		int dorw=0;
		try {
			System.out.println("enter customer name");
			name = br.readLine();
			System.out.println("enter customer age");
			age = Float.parseFloat(br.readLine());
			System.out.println("Select from following");
			System.out.println("1:deposit");
			System.out.println("2:withdraw");
			dorw=Integer.parseInt(br.readLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		Account4_1  acc= new Account4_1();
		
		acc.setName(name);
		acc.setAge(age);

		acc.setAccountNum(accNum);
		System.out.println(acc.toString());
		switch (dorw) {
		case 1:
			System.out.println("enter the amount you want to deposit");
			Integer amountd = 0;
			try {
				amountd = Integer.parseInt(br.readLine());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			acc.deposit(amountd);
			break;

		case 2:
			System.out.println("enter the amount you want to withdraw");
			Integer amountw = 0;
			try {
				amountw = Integer.parseInt(br.readLine());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			acc.withdraw(amountw);
			break;

		default:
			break;
			
			
		
		}*/
		
	
		
		
	}
}
