package com.capglab;

public class PositiveOrNegative {
	
	public static void main(String[] args) {
		
		String s=args[0];
		int i=Integer.valueOf(s);
		if (i>0)
		{
			System.out.println("no. is positive");
		}
		else if(i<0)
		{
			System.out.println("no. is negative");
		}
		else
		{
			System.out.println("no. is 0");
		}
		
	}

}
