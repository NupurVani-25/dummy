package com.capglab;

public class Printing {

	public static void main(String[] args) {
	System.out.println("Person Details:");

	System.out.println("--------------");
	System.out.println("First name:Divya");
	System.out.println("last name:Bharati");
	System.out.println("Age:20");
	System.out.println("Gender: F");
	System.out.println("Weight:85.55");
	}

}
