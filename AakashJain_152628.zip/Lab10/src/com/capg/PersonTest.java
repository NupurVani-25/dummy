package com.capg;

import static org.junit.Assert.assertEquals;


import org.junit.jupiter.api.Test;

class PersonTest extends Person {

	Person person=new Person();
	
	@Test
	void testGetFirstName() {
	person.setFirstName("aakash");
	assertEquals("aakash",person.getFirstName());
	
	
	}

	@Test
	void testGetLastName() {
		person.setLastName("jain");
		assertEquals("jain",person.getLastName());
	}

	@Test
	void testGetGender() {
		person.setGender("M");
		assertEquals("M",person.getGender());
	}

}
