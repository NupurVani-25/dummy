package com.capg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DateTest extends Date {

	DateTest(int intDay, int intMonth, int intYear) {
		super(intDay, intMonth, intYear);
		// TODO Auto-generated constructor stub
	}

	@Test
	void testDate() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDay() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDay() {

        Date d=new Date(2,11,2018);
        assertEquals(2,d.getDay());
        
	}

	@Test
	void testSetMonth() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMonth() {
		fail("Not yet implemented");
	}

	@Test
	void testSetYear() {
		fail("Not yet implemented");
	}

	@Test
	void testGetYear() {
		fail("Not yet implemented");
	}

}
