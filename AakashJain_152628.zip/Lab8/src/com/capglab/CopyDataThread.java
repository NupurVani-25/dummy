package com.capglab;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class CopyDataThread extends Thread {

	public CopyDataThread(FileInputStream fis,FileOutputStream fos)
	{
		try {
		int i;
		
		
			i=fis.read();
		
		int count =0;
		
		while(i !=-1)
		{
			fos.write(1);
					i=fis.read();
					count++;
				
					if(count==10)
					{
						System.out.println("10 characters are copied");
						
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						count=0;
					}
					
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	}

	
	

