package com.capglab;

public class Program2 implements Runnable{

	public static void main(String[] args) {
		
		Program2 obj=new Program2();
		Thread t=new Thread(obj);
		t.start();
	}
	
	@Override
	public void run() {
		
		
		while(true) {
		System.out.println(System.currentTimeMillis());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

	
	
}
