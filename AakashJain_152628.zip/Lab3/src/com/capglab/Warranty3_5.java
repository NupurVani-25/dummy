package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import java.time.format.DateTimeFormatter;


public class Warranty3_5 {
	
	public static void main(String[] args) {

BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
try {
	System.out.println("enter a purchase date:");
	String edate=br.readLine();
	System.out.println("enter the no. of months after product will expire:");
	int emonths=Integer.parseInt(br.readLine());
	System.out.println("enter the no. of year after product will expire:");
	int eyears=Integer.parseInt(br.readLine());
	
	DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd");
	LocalDate date=LocalDate.parse(edate, dtf);
	System.out.println(date);
	System.out.println("warranty expires on :"+date.plusMonths(emonths).plusYears(eyears));
	
} catch (NumberFormatException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
}