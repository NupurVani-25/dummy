package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class DateDuration3_4 {
	
	public static void main(String[] args) {

BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
try {
	System.out.println("enter a date:");
	
	String date1=br.readLine();
	System.out.println("enter a date:");
	String date2=br.readLine();
	DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd");
	LocalDate d1=LocalDate.parse(date1, dtf);
	LocalDate d2=LocalDate.parse(date2, dtf);
	
	Period dif=Period.between(d1, d2);
	System.out.println("Difference between the dates: no. of days" +" "+ dif.getDays()+" "+"no. of months"+" "+dif.getMonths()+" "+"no. of years"+" "+ dif.getYears());
	
	
	
} catch (NumberFormatException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
}