package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class StringSort {
	public static void main(String[] args) {
		System.out.println("Enter a string:");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String inputString=null;
		try {
			inputString = br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringSort ss=new StringSort();
		ss.positiveString(inputString);

}

	public void positiveString(String s)
	{
		char[] str=s.toCharArray();
	   Arrays.sort(str);
	   System.out.println(str);
	}
}


