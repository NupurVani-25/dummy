package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Zone3_6 {

	public static void main(String[] args) {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter zone :");
		try {
			String id=br.readLine();
			
			Zone3_6 z=new Zone3_6();
			z.zone(id);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
		
	}

	public void zone(String zid) 
	{
		ZonedDateTime zdt=ZonedDateTime.now(ZoneId.of(zid));
		System.out.println("Date and time in the zone"+zdt);
		
	}
	
}
