package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringOperations {

	public static void main(String[] args) {
		StringOperations so=new StringOperations();
		System.out.println("enter a string:");
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		String inputString = null;
		try {
			inputString = br.readLine();
			so.operations(inputString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	

		

		
		
	
	public void operations(String s ) {
			
			System.out.println("1:add string to itself");
			System.out.println("2:replace odd positons with #");
			System.out.println("3:remove duplicate numbers in string");
			System.out.println("4:change odd characters to upper case");
			BufferedReader br1= new BufferedReader(new InputStreamReader(System.in));
		
			
				int no=0;
				try {
					no = Integer.parseInt(br1.readLine());
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				switch (no) {
				case 1:
					System.out.println(s.concat(s));
					
					break;
				case 2:
					char[] a=s.toCharArray();
					for (int i = 0; i < a.length; i++) {
						if(i%2==0)
						{
							a[i]='#';
						}					
					}
					System.out.println(a);
					
					break;
				case 3:
					StringBuilder sb=new StringBuilder(s);
					char[] c=s.toCharArray();
					
					for (int i = 0; i < c.length; i++) {
						for (int k = i+1; k < c.length; k++) {
							if(s.charAt(i)==s.charAt(k))
							{
							sb.deleteCharAt(i);
							}
						}
					}
					System.out.println(sb);
		
					break;
				case 4:
					char[] b=s.toCharArray();
					for (int i = 0; i < b.length; i++) {
						if(i%2==0)
						{
							b[i]=Character.toUpperCase(b[i]);
						}					
					}
					System.out.println(b);
					
		
					break;	

				default:
					break;
				}
			} 

	}


