package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Arrays;


public class StringArraySort3_8 {

	public static void main(String[] args) {

		StringArraySort3_8  sas=new StringArraySort3_8();
		sas.accept();
		
	}

	public void accept() {
		
		
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no. of strings you want ot enter:");
		int no=0;
		try {
				no = Integer.parseInt(br.readLine());
				String[] str=new String[no];
				System.out.println("enter the strings you want to sort:");
				
			
				for (int i = 0; i < no; i++) 
				{
					str[i]=br.readLine();				
					
				}
			    Arrays.sort(str);
			   
				
				if(no%2==0)
				{
					for (int i = 0; i < no/2; i++)
					{
						str[i]=str[i].toUpperCase();						
					}
				}
				else 
					{
					for (int i = 0; i < no/2+1; i++) {
						str[i]=str[i].toUpperCase();	
					}
				    }
					
				for (int i = 0; i < str.length; i++) 
				{
					
				System.out.println(str[i]);
				}
		}
				
				 catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}

