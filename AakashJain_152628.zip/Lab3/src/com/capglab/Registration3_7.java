package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Registration3_7 {

	public static void main(String[] args) {
	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
			System.out.println("enter username:");
			
			try {
				 String applicantname=br.readLine();
				Registration3_7 r= new Registration3_7();
				r.validation(applicantname);
				
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
	}
	 public boolean validation(String s)
	 {
		 if(s.length()>=12 && s.endsWith("_job"))
			{
			System.out.println("validated");	
			 return true;
			}
		 else
			{
			 System.out.println("failure");
				return false;
			}
	
		 
}}
