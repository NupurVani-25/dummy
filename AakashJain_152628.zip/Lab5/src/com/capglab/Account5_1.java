package com.capglab;

public abstract class Account5_1 extends Person5_1 {
private long accountNum;
public double balance;
private Person5_1 accHolder;

public void deposit(double d) 
	{
	   balance=balance+d;
	   System.out.println("account balance is"+ balance);
	}
public abstract double withdraw(double w) ;
	
public double getBalance()
	{
	 return balance;
	}

public long getAccountNum() {
	return accountNum;
}
public void getBalance(double balance) {
	this.balance = balance;
}	
public void setAccHolder(Person5_1 accHolder) {
	this.accHolder= accHolder;
}
public String getAccHolder() {
	return accHolder.getName();
}
public void setAccountNum(long accountNum) {
	this.accountNum = accountNum;
}
public void setBalance(double balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "Account5_1 [accountNum=" + accountNum + ", balance=" + balance + ", accHolder=" + getName() + "]";
}


}
