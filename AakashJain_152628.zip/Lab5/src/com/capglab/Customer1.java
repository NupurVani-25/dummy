package com.capglab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Customer1 {

	public static void main(String[] args) {		
		
		System.out.println("*********welcome to our app*********");
		
	
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("welcome to customer app");
		
		try {
			
			Customer cust=new Customer();
			
			System.out.println("Enter Customerid");
			int cid= Integer.parseInt(br.readLine());
			cust.setCid(cid);
			System.out.println("Enter CustomerName");
			String cname=br.readLine();
			cust.setCname(cname);
			System.out.println("Enter CustomerAmount");
			double amount= Double.parseDouble(br.readLine());
			cust.setAmount(amount);
		
		
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
