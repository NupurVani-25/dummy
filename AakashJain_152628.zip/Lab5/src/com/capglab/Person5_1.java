package com.capglab;

public class Person5_1 {
	private String name;
	private float age;
	
	public String getName() {
		return name;
	}
	public float getAge() {
		return age;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(float age) {
		this.age = age;
	}
	

}
