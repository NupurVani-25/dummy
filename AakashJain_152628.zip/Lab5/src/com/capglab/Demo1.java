package com.capglab;

public class Demo1 {

	public static void main(String[] args) {
		Employee e1=new Employee();
		System.out.println(e1);
		
	}

}
