package com.capglab;

public class Withdraw5_1 extends Account5_1{

	@Override
	public double withdraw(double w) {
		{
			  balance=balance-w;
			  if(balance<500)
			  {
				  System.out.println("no balance");
				  return w;
			  }
			  return balance+w;
			}
	
	}

}
