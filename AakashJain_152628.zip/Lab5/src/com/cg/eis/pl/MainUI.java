package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainUI {

	public static void main(String[] args) {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		 Employee emp= new Employee();
		
		try {
			System.out.println("Enter your id");
			int eid=Integer.parseInt(br.readLine());
			emp.setId(eid);
			System.out.println("Enter your name");
			String ename=br.readLine();
			emp.setName(ename);
			System.out.println("Enter your salary");
			int esal=Integer.parseInt(br.readLine());
			emp.setSalary(esal);
			System.out.println("Enter your designation");
			String edesig=br.readLine();
			emp.setDesignation(edesig);
			
			EmployeeService obj = new EmployeeService();
			obj.insuranceScheme(emp);
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public void printcall()
		{
			
		}
		
		
	}

	

