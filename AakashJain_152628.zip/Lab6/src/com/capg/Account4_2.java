package com.capg;

import com.capg.Person4_2;

public class Account4_2 extends Person4_2 {



	private long accountNum;
	private double balance;
	private Person4_2 accHolder;

	public void deposit(double d) 
		{
		   balance=balance+d;
		   System.out.println("account balance is"+ balance);
		}
	public boolean withdraw(double w) 
		{
		  balance=balance-w;
		  if(balance<500)
		  {
			  System.out.println("no balance");
			  return true;
		  }
		  return false;
		}
	public double getBalance()
		{
		 return balance;
		}
	
	public long getAccountNum() {
		return accountNum;
	}
	public void getBalance(double balance) {
		this.balance = balance;
	}	
	public String getAccHolder() {
		return accHolder.getName();
	}
	public void setAccountNum(long accountNum) {
		this.accountNum = accountNum;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void setAccHolder(Person4_2 accHolder) {
		this.accHolder = accHolder;
	}
	@Override
	public String toString() {
		return " [accountNum=" + accountNum + ", balance=" + balance + ", age" + getAge()+ "]";
	}
	
	}


