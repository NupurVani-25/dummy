package com.capg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PersonMain {



		public static void main(String[] args) {

	       Person p=new Person();
//	       p.setFirstName("aakash");
//	       p.setLastName("jain");
//	       p.setGender("M");
//
//	       
//	       System.out.println("First name:"+p.getFirstName());
//	   	System.out.println("last name:"+p.getLastName());
//	   	System.out.println("Gender:"+p.getGender());
//	   	
	   	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   	try {
	   		System.out.println("Person Details:");

	   		System.out.println("--------------");
	   		System.out.println("Enter First name:");
	   		String fname=br.readLine();
		
	   		System.out.println("Enter last name:");
	   		String lname=br.readLine();
			
	   		System.out.println("Enter Gender:");
	   		String gen=br.readLine();
	   		p.setGender(gen);
	   		
	  
	   		System.out.println("Enter Mobile no:");
	   		int mobile=Integer.parseInt(br.readLine());
	   		
	   		
	   		if(fname.isEmpty() || lname.isEmpty())
	   	{
	   			try {
					throw new ValidateException();
				} catch (ValidateException e) {
					System.err.println("enter first name and last name");
				}
	   	}
	   		else
	   		{
	   		p.setFirstName(fname);
	   		p.setLastName(lname);
	   		
	   		
	   		
	   		System.out.println("Person Details:");
	   		System.out.println("--------------");
	   		System.out.println("First name:"+p.getFirstName());
	   		System.out.println("last name:"+p.getLastName());
	   		System.out.println("Gender:"+p.getGender());
	   		System.out.println("entered mobile no."+ mobile);
	   		}
	   		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
		}

	}

