package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;


public class EmployeeService   implements EmployeeServiceInterface
	{
	

	
	
  
	 
	 @Override
	 public void insuranceScheme(Employee obj) {
		 int sal=obj.getSalary();
		 System.out.println(sal);
	
		 if(sal>=5000 && sal< 20000)
		 {
			 obj.setDesignation("System Associate");
			 System.out.println("System Associate");		
			 System.out.println("Scheme C");
			 obj.setEmployeeInsuranceScheme("C");
		 }
		 else if(sal>=20000 && sal<40000)
		 {
			 obj.setDesignation("Programmer");
			 System.out.println("Programmer");
			 System.out.println("Scheme B");
			 obj.setEmployeeInsuranceScheme("B");
		 }
		 else if(sal>=40000)
		 {
			 obj.setDesignation("Manager");
			 System.out.println("Manager");
			 System.out.println("Scheme A");
			 obj.setEmployeeInsuranceScheme("A");
		 }
		 else if(sal<5000)
		 {
			 obj.setDesignation("Clerk");
			 System.out.println("Clerk");
			 System.out.println("no scheme");
		 }
		 
		 else if(sal<3000)
		 {
			 try {
				throw new EmployeeException();
			} catch (EmployeeException e) {
				System.out.println("no insurance scheme available");
			}
		 }
		 else
		 {
			 System.out.println("enter valid details");
		 }
	 
		 
		 	System.out.println(obj.getId());
			System.out.println(obj.getName());
			System.out.println(obj.getSalary());
			System.out.println(obj.getDesignation());
			System.out.println(obj.getEmployeeInsuranceScheme());
	 }

}
