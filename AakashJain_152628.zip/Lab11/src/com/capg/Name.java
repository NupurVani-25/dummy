package com.capg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Name {

public static void main(String[] args) {
	

	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter username");
	
	try {
		String name=br.readLine();
		System.out.println("Enter Password");
		long p=Long.parseLong(br.readLine());
		
		IName iname=(uname,password)->
		{
			boolean b;
			if (name.equals("aakash")&& p ==123456)
				b=true;
			else
				b=false;
			
			return b;
		};
		System.out.println("the result is"+ iname.name(name,p));
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	
}	
}
