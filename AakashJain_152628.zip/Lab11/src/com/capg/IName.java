package com.capg;

@FunctionalInterface
public interface IName {
	
	boolean name(String uname,long password);
	
}
