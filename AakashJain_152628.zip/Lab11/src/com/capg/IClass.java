package com.capg;

public interface IClass {

	ItemClass get(String name,double price);
	
}
