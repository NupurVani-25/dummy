package com.capg;

@FunctionalInterface
public interface ISpaceInsert {

	String space(String str);
	
}
