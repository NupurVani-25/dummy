package com.capg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SpaceInsert {

	public static void main(String[] args) {
		
		System.out.println("Enter input string");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try {
			String inputString=br.readLine();
		
		StringBuilder sb=new StringBuilder();
		ISpaceInsert s=(str) ->
		{
			sb.append(str);
			for(int i=1;i<sb.length();i++)
			{
				sb.insert(i," ");
				i++;
			}
			return sb.toString();	
		};
		
		System.out.println("New String:"+s.space(inputString));
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
}
