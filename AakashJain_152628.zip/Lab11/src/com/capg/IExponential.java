package com.capg;

@FunctionalInterface
public interface IExponential {

	public double power(double num1,double num2);
	
}
