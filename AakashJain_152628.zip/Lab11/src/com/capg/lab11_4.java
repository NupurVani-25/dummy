package com.capg;

public class lab11_4 {

	public static void main(String[] args) {
		
		IClass i=ItemClass::new;
		System.out.println(i.get("vbb",000.00));
		
	}
	
}
