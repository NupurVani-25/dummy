package com.cg.Paymentwallet.exception;

public class PaymentWalletException extends Exception{
public PaymentWalletException()
{
}
public PaymentWalletException(String message) {
	super(message);
}
}
