package com.cg.Paymentwallet.exception;

public interface IPaymentWalletException {
String Message1="Name should contain only alphabets and should start with Uppercase...";

}
