package com.cg.Paymentwallet.service;

public class PaymentWalletService implements IPaymentWalletService{

	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean validatePhoneNumber(long phone) {
		// TODO Auto-generated method stub
		return false;
	}

}
