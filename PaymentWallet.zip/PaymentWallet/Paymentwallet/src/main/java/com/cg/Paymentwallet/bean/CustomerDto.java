package com.cg.Paymentwallet.bean;

public class CustomerDto {
private String name;
private long phoneNumber;
private String email;
private double balance;
private int age;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
 public CustomerDto()
 {
 }
 public CustomerDto(String name, String email, long phoneNumber, int age, double balance)
 {
	 this.name=name;
	 this.age=age;
	 this.phoneNumber=phoneNumber;
	 this.email=email;
	 this.balance=balance;
 }
}
