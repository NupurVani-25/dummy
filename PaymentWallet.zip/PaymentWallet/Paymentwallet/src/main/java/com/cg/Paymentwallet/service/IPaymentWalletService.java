package com.cg.Paymentwallet.service;

public interface IPaymentWalletService {
public boolean validateName(String name);
public boolean validatePhoneNumber(long phone);
}
